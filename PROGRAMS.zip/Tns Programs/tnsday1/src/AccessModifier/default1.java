package AccessModifier;

public class default1 {
	void display() {
		System.out.println("Hellow World");
	}

}

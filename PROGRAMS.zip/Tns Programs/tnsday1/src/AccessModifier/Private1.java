package AccessModifier;

public class Private1 {
	Private void display()
	{
		System.out.println("TNS session");
	}

}

package AccessModifier;

public class protected1 {
	protected void display() {
		System.out.println("aa");
	}

}

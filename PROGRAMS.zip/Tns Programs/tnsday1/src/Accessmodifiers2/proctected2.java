package Accessmodifiers2;

public class proctected2 extends protected1 {
	

	public static void main(String[] args) {
		procted2 obj=new procted2();
		obj.display();
		

	}

}

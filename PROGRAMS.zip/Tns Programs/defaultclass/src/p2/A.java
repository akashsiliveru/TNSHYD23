package p1;

 class MyClass1 {
	 void display() {
		 System.out.println("Hellow world");
	 }
 }
 

	}

}

/**
 * 
 */
/**
 * 
 */
module sample2 {
}
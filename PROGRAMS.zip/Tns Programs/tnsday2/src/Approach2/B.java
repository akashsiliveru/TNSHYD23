package Approach2;

import approach1.A;

class B{
	int a=10;
	static int b=20;
	int display() {
		return a ;//instance method
		}
	static void display1() {
	System.out.println(b);
		}
 class C{

	public static void main(String[] args) {
		B a1 = new B();
    	System.out.println(a1.a);
    	System.out.println(B.b);
    	
    	//methods
    	System.out.println("********************");
    	System.out.println(a1.display());
    
    	B.display1();
	}
		

	}

}

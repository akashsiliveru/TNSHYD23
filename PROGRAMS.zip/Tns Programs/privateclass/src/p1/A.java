package p1;

 class A {
	 
	private void display()
	{
		System.out.println("TNS session");
		
	}
	public static void main(String[] args) {
		
	
	A obj=new A();
	
	System.out.println(obj.display());
}}
 
